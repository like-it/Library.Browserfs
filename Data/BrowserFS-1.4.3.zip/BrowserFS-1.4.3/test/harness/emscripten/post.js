// Appended to end of Emscripten output.
Module['FS'] = FS;
Module['IDBFS'] = IDBFS;
Module['PATH'] = PATH;
Module['ERRNO_CODES'] = ERRNO_CODES;
};
