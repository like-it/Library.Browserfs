// Appended before Emscripten output.
module.exports = function(Module) {
