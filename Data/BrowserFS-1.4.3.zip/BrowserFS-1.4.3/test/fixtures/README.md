This directory contains data files used during testing.

* `files`: Generic test files shared by all backends
* `dropbox` (dynamically generated): Certification information used by `dropbox-js`.
* `zipfs` (dynamically generated): Multiple zipped versions of `files`.
