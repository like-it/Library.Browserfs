// Does nothing.
// Used for other Emscripten testing.
int main() {

}
