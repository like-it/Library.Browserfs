This folder contains the source files for BrowserFS.

* `core`: Contains the 'core' of BrowserFS including interfaces and API definitions.
* `generic`: Contains 'generic' building blocks that multiple backends share (e.g. `File` implementations and index classes).
* `backend`: Contains backend-specific files.
